let dados=`<compromissos>
    <compromisso>
        <titulo>Reunião</titulo>
        <descricao>Reunião de produtividade</descricao>
        <data>17/02/2022</data>
        <local>Escritório</local>
    </compromisso>
    <compromisso>
        <titulo>Campeonato</titulo>
        <descricao>Campeonato de tênis de mesa</descricao>
        <data>20/02/2022</data>
        <local>Ginásio</local>
    </compromisso>
    <compromisso>
        <titulo>Consulta</titulo>
        <descricao>Médico Dr André</descricao>
        <data>22/02/2022</data>
        <local>Hospital HGP</local>
    </compromisso>
</compromissos>`;
localStorage.setItem("dados", dados);